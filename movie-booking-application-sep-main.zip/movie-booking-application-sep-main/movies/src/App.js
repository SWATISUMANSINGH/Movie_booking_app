import './App.css';
import Header from './components/Header';

function App() {
  return (
    <div className="App">
<Header />
    </div>
  );
}

export default App;

//four screens
 
// 1. HOmepage with movies
// 2. movie crud operations
// 3. Authentication forms
// 4. profiles